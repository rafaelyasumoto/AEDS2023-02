#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int compare(const void *a, const void *b) {
    return (*(int*)a - *(int*)b);
}

double calcularMedia(int numeros[], int tamanho) {
    int soma = 0;
    for (int i = 0; i < tamanho; i++) {
        soma += numeros[i];
    }
    return (double)soma / tamanho;
}

double calcularMediana(int numeros[], int tamanho) {

    qsort(numeros, tamanho, sizeof(int), compare);

    if (tamanho % 2 != 0) {
        return numeros[tamanho / 2];
    }

    else {
        return (numeros[tamanho / 2 - 1] + numeros[tamanho / 2]) / 2.0;
    }
}


int calcularModa(int numeros[], int tamanho) {
    int moda = numeros[0];
    int contagem = 1;
    int maxModa = 1;

    for (int i = 1; i < tamanho; i++) {
        if (numeros[i] == numeros[i - 1]) {
            contagem++;
        } else {
            contagem = 1;
        }

        if (contagem > maxModa) {
            maxModa = contagem;
            moda = numeros[i];
        }
    }

    return moda;
}


double calcularDesvioPadrao(int numeros[], int tamanho, double media) {
    double somaQuadrados = 0;

    for (int i = 0; i < tamanho; i++) {
        somaQuadrados += pow(numeros[i] - media, 2);
    }

    return sqrt(somaQuadrados / tamanho);
}

int main() {
    int numeros[1000]; //
    int n = 0;


    int num;
    do {
        printf("Digite um numero natural (digite 0 para encerrar): ");
        scanf("%d", &num);

        if (num != 0) {
            numeros[n++] = num;
        }
    } while (num != 0);

    if (n == 0) {
        printf("Nenhum numero foi digitado.\n");
        return 1;
    }


    double media = calcularMedia(numeros, n);
    double mediana = calcularMediana(numeros, n);
    int moda = calcularModa(numeros, n);
    double desvioPadrao = calcularDesvioPadrao(numeros, n, media);


    printf("Media: %.2f\n", media);
    printf("Mediana: %.2f\n", mediana);
    printf("Moda: %d\n", moda);
    printf("Desvio Padrao: %.2f\n", desvioPadrao);

    return 0;
}
