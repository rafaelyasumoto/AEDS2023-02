#include <stdio.h>
#include <stdlib.h>

int main()
{
    int vetor[10];
    int aux = 0;
    for(int i=0; i<10; i++){
        printf("Digite o valor: ");
        scanf("%i", &vetor[i]);
    }
    for(int i=0; i<10; i++){
       if(vetor[i]> aux){
        aux = vetor[i];
       }
    }
    printf("\nMaior valor: %i", aux);
    return 0;
}
