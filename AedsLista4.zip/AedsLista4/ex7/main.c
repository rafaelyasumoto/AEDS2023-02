#include <stdio.h>


int ehPrimo(int num) {
    if (num <= 1) {
        return 0;
    }

    for (int i = 2; i * i <= num; i++) {
        if (num % i == 0) {
            return 0;
        }
    }

    return 1;
}

int main() {
    int n;


    printf("Digite um numero natural n: ");
    scanf("%d", &n);

    if (n <= 0) {
        printf("Por favor, insira um numero natural positivo.\n");
        return 1;
    }

    printf("Os %d primeiros numeros primos sao:\n", n);

    int contador = 0;
    int i = 2;


    while (contador < n) {
        if (ehPrimo(i)) {
            printf("%d ", i);
            contador++;
        }
        i++;
    }

    return 0;
}
