#include <stdio.h>

int calcularCoeficienteBinomial(int n, int k) {
    if (k == 0 || k == n) {
        return 1;
    } else {
        return calcularCoeficienteBinomial(n - 1, k - 1) + calcularCoeficienteBinomial(n - 1, k);
    }
}

void imprimirTrianguloPascal(int n) {
    for (int linha = 0; linha < n; linha++) {
        for (int espaco = 0; espaco < n - linha - 1; espaco++) {
            printf(" ");
        }

        for (int coluna = 0; coluna <= linha; coluna++) {
            printf("%d ", calcularCoeficienteBinomial(linha, coluna));
        }

        printf("\n");
    }
}

int main() {
    int n;

    printf("Digite o numero de linhas para o Triangulo de Pascal: ");
    scanf("%d", &n);

    imprimirTrianguloPascal(n);

    return 0;
}
