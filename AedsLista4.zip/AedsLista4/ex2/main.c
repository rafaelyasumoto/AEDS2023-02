#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int vetor[10];
    int valor, aux=0;
    for(int i=0; i<10; i++){
        printf("Digite o valor: ");
        scanf("%i", &vetor[i]);
    }
    printf("\nDigite o valor para ver o numero de ocorrencias do mesmo: ");
    scanf("%i", &valor);
    for(int i=0; i<10; i++){
        if(vetor[i]==valor){
            aux++;
        }
    }
    printf("\nO valor foi lido %i vezes", aux);
    return 0;


}
