#include <stdio.h>
#include <string.h>
#include <ctype.h>



int palindromo(char *str, int inicio, int fim) {
    while (inicio < fim) {
        if (tolower(str[inicio]) != tolower(str[fim])) {
            return 0;
        }
        inicio++;
        fim--;
    }
    return 1;
}

int main() {
    char frase[100];


    printf("Digite uma frase: ");
    fgets(frase, 100, stdin);

    frase[strcspn(frase, "\n")] = '\0';

    int len = strlen(frase);
    int i, j;


    printf("Palindromos encontrados:\n");
    for (i = 0; i < len; i++) {
        for (j = i + 3; j < len; j++) {
            if (frase[i] != ' ' && frase[j] != ' ' && palindromo(frase, i, j)) {
                for (int k = i; k <= j; k++) {
                    printf("%c", frase[k]);
                }
                printf("\n");
            }
        }
    }

    return 0;
}
