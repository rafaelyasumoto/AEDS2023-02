#include <stdio.h>

int main() {
    int LinhaA, ColunaA, LinhaB, ColunaB;

    printf("Digite o n�mero de linhas e colunas da matriz A: ");
    scanf("%d %d", &LinhaA, &ColunaA);

    printf("Digite o n�mero de linhas e colunas da matriz B: ");
    scanf("%d %d", &LinhaB, &ColunaB);

    if (ColunaA != LinhaB) {
        printf("N�o � poss�vel multiplicar as matrizes A e B. O n�mero de colunas de A deve ser igual ao n�mero de linhas de B.\n");
        return 1;  // C�digo de erro
    }

    int matrixA[LinhaA][ColunaA];
    printf("Digite os elementos da matriz A por linha:\n");
    for (int i = 0; i < LinhaA; ++i) {
        for (int j = 0; j < ColunaA; ++j) {
            scanf("%d", &matrixA[i][j]);
        }
    }


    int matrixB[LinhaB][ColunaB];
    printf("Digite os elementos da matriz B por linha:\n");
    for (int i = 0; i < LinhaB; ++i) {
        for (int j = 0; j < ColunaB; ++j) {
            scanf("%d", &matrixB[i][j]);
        }
    }

    int result[LinhaA][ColunaB];

    for (int i = 0; i < LinhaA; ++i) {
        for (int j = 0; j < ColunaB; ++j) {
            result[i][j] = 0;
            for (int k = 0; k < ColunaA; ++k) {
                result[i][j] += matrixA[i][k] * matrixB[k][j];
            }
        }
    }


    printf("\nResultado do produto A x B:\n");
    for (int i = 0; i < LinhaA; ++i) {
        for (int j = 0; j < ColunaB; ++j) {
            printf("%d\t", result[i][j]);
        }
        printf("\n");
    }

    return 0;
}
