#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int vetor[10];
    int temp = 0;
    for(int i=0; i<10; i++){
        printf("Digite o valor: ");
        scanf("%i", &vetor[i]);
    }
     for (int i = 0; i < 9; i++) {
        for (int j = 0; j < 10 - i - 1; j++) {
            if (vetor[j] > vetor[j + 1]) {
                temp = vetor[j];
                vetor[j] = vetor[j + 1];
                vetor[j + 1] = temp;
            }
        }
    }

    printf("\n");
    for(int i=0; i<10; i++){
        printf("%i ", vetor[i]);
    }
    return 0;


}
