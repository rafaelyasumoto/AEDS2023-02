#include <stdio.h>
#include <math.h>

#define MAX_SIZE 100

void leMatriz(int n, double matriz[MAX_SIZE][MAX_SIZE]) {
    printf("Digite os elementos da matriz (%dx%d):\n", n, n);
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            printf("Matriz[%d][%d]: ", i, j);
            scanf("%lf", &matriz[i][j]);
        }
    }
}

void imprimeMatriz(int n, double matriz[MAX_SIZE][MAX_SIZE]) {
    printf("Matriz:\n");
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            printf("%.2f\t", matriz[i][j]);
        }
        printf("\n");
    }
}

double calculaDeterminante(int n, double matriz[MAX_SIZE][MAX_SIZE]) {
    double det = 0;

    if (n == 1) {
        return matriz[0][0];
    } else if (n == 2) {
        return matriz[0][0] * matriz[1][1] - matriz[0][1] * matriz[1][0];
    } else {
        for (int i = 0; i < n; ++i) {
            double submatriz[MAX_SIZE][MAX_SIZE];
            for (int j = 1; j < n; ++j) {
                for (int k = 0; k < n; ++k) {
                    if (k < i) {
                        submatriz[j - 1][k] = matriz[j][k];
                    } else if (k > i) {
                        submatriz[j - 1][k - 1] = matriz[j][k];
                    }
                }
            }
            det += matriz[0][i] * pow(-1, i) * calculaDeterminante(n - 1, submatriz);
        }
    }

    return det;
}

int main() {
    int n;

    printf("Digite a dimensao da matriz: ");
    scanf("%d", &n);

    if (n < 1 || n > MAX_SIZE) {
        printf("Dimensao invalida.\n");
        return 1;
    }

    double matriz[MAX_SIZE][MAX_SIZE];

    leMatriz(n, matriz);
    imprimeMatriz(n, matriz);

    double determinante = calculaDeterminante(n, matriz);
    printf("\nDeterminante: %.2f\n", determinante);

    printf("\nDiagonal Principal:\n");
    for (int i = 0; i < n; ++i) {
        printf("%.2f\t", matriz[i][i]);
    }
    printf("\n");

    return 0;
}
