#include <stdio.h>
#include <string.h>
#include <ctype.h>


int main() {
    char frase[100];
    int i, j;
    printf("Digite uma frase: ");
    fgets(frase, 100, stdin);
    frase[strcspn(frase, "\n")] = '\0';
    i = 0;
    j = strlen(frase) - 1;
    while (i < j) {
        while (!isalnum(frase[i]) && i < j) {
            i++;
        }
        while (!isalnum(frase[j]) && i < j) {
            j--;
        }

        if (tolower(frase[i]) != tolower(frase[j])) {
            printf("A frase nao e um palindromo.\n");
            return 0;
        }


        i++;
        j--;
    }
    printf("A frase e um palindromo.\n");

    return 0;
}
