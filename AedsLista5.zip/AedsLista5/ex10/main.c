#include <stdio.h>

int calcularPascal(int linha, int coluna) {
    if (coluna == 0 || coluna == linha) {
        return 1;
    } else {
        return calcularPascal(linha - 1, coluna - 1) + calcularPascal(linha - 1, coluna);
    }
}


void imprimirTrianguloPascal(int n) {
    if (n <= 0) {
        return;
    }

    for (int i = 0; i < n; i++) {
        printf("%d ", calcularPascal(n - 1, i));
    }

    printf("\n");


    imprimirTrianguloPascal(n - 1);
}

int main() {
    int n;

    printf("Digite o numero de linhas do Triangulo de Pascal: ");
    scanf("%d", &n);

    if (n <= 0) {
        printf("O numero de linhas deve ser maior que zero.\n");
    } else {
        imprimirTrianguloPascal(n);
    }

    return 0;
}
