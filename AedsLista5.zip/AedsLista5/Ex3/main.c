#include <stdio.h>
#include <stdlib.h>
#include <math.h>
float calculosomatorio(float n)
{
    float resultado;
    for(int i=1;i<=n;i++)
    {
        resultado += ((pow(-1,i-1)*(4/2*i-1)));
    }
}

int main()
{

    return 0;
}
