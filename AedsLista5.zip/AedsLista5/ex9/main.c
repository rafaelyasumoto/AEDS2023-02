#include <stdio.h>

int fibonacci(int n) {
    if (n <= 1) {
        return n;
    } else {
        return fibonacci(n - 1) + fibonacci(n - 2);
    }
}

void imprimirFibonacci(int n) {
    if (n < 0) {
        printf("Numeros negativos nao sao permitidos.\n");
        return;
    }

    for (int i = 0; i < n; i++) {
        printf("%d ", fibonacci(i));
    }
    printf("\n");
}

int main() {
    int n;

    printf("Digite o numero de termos da sequencia de Fibonacci a serem impressos: ");
    scanf("%d", &n);

    imprimirFibonacci(n);

    return 0;
}
