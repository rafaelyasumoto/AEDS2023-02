#include <stdio.h>

void imprimeTriangulo(int n, int linha) {
    if (linha > n) {
        return;
    }

    for (int i = 0; i < linha; i++) {
        printf("*");
    }

    printf("\n");
    imprimeTriangulo(n, linha + 1);
}

int main() {
    int n;
    printf("Digite o n�mero de linhas do tri�ngulo: ");
    scanf("%d", &n);

    imprimeTriangulo(n, 1);

    return 0;
}
