#include <stdio.h>
#include <string.h>
#include <stdlib.h>

float[] somavalor (float v1[], int n1, float v2[], int n2)
{
    int i, m;
    if(n1>n2){
        m = n2;
    }else
    {
        m=n1;
    }
    float*v3=(float*)malloc(sizeof(float)*m);
    if(v3==NULL){
        return NULL;
    }
    for(i=0;i<m;i++){
        v3[i]=v1[i]+v2[i];
    }
    return v3;
}

int main() {


    return 0;
}
