#include <stdio.h>
#include <string.h>

void tri (int n)
{
    if(n<=0){
        return;
    }
    if(n==1){
            printf("*\n");
        return;
    }
    tri(n-1);
    for(int i=0;i<n;i++){
        printf("*");
    }
    printf("\n");
}


int main() {

    return 0;
}
