#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

bool parimpar(int valor)
{
    bool resultado;
    if(valor%2==0){
        resultado =1;
    }else{
        resultado = 0;
    }
    return resultado;
}

int main()
{
    int valor;
    bool resultado2;
    printf("Digite um valor: ");
    scanf("%i", &valor);
    resultado2 = parimpar(valor);
    if(resultado2 == 1){
        printf("\nResultado 1, numero par");
    }else{
         printf("\nResultado 0, numero impar");
    }

    return 0;
}
