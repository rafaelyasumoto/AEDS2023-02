#include <stdio.h>

void somaDoisVetores(int vetor1[], int vetor2[], int resultado[], int tamanho) {
    for (int i = 0; i < tamanho; i++) {
        resultado[i] = vetor1[i] + vetor2[i];
    }
}

int main() {
    int tamanho = 5;
    int vetor1[tamanho], vetor2[tamanho], resultado[tamanho];
    printf("Vetor 1: ");
    for (int i = 0; i < tamanho; i++) {
        scanf("%d", &vetor1[i]);
    }
    printf("Vetor 2: ");
    for (int i = 0; i < tamanho; i++) {
        scanf("%d", &vetor2[i]);
    }
    somaDoisVetores(vetor1, vetor2, resultado, tamanho);
    printf("Resultado: ");
    for (int i = 0; i < tamanho; i++) {
        printf("%d ", resultado[i]);
    }

    return 0;
}
