#include <stdio.h>
#include <stdlib.h>
#include <math.h>
void fibonacci(int n)
{
    int vetor[n];
    for(int i=0; i<n;i++){
        vetor[0]=0;
        vetor[1]=1;
           if(i==0){
        printf("0, ", vetor[0]);
    }
     else if(i==1){
        printf("1, ");
    }else{
        vetor[i]= vetor[i-1]+vetor[i-2];
        printf("%i, ", vetor[i] );
    }
    }
}

int main()
{
    int n;
    printf("Digite a quantidade de termos de fibonacci: ");
    scanf("%i", &n);
    if(n<=0){
        printf("Numero invalido!");
        return;
    }
    fibonacci(n);
    return 0;
}
