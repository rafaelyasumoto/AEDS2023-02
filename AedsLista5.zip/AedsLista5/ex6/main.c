#include <stdio.h>
#include <stdlib.h>

int** multiplicaMatrizes(int** matriz1, int** matriz2, int linhas1, int colunas1, int colunas2) {

    if (colunas1 != linhas1) {
        return NULL;
    }

    int** resultado = (int**)malloc(linhas1 * sizeof(int*));
    for (int i = 0; i < linhas1; i++) {
        resultado[i] = (int*)malloc(colunas2 * sizeof(int));
    }

    for (int i = 0; i < linhas1; i++) {
        for (int j = 0; j < colunas2; j++) {
            resultado[i][j] = 0;
            for (int k = 0; k < colunas1; k++) {
                resultado[i][j] += matriz1[i][k] * matriz2[k][j];
            }
        }
    }

    return resultado;
}

int main() {
    int linhas1, colunas1, colunas2;

    linhas1 = 2;
    colunas1 = 3;
    colunas2 = 2;

    int** matriz1 = (int**)malloc(linhas1 * sizeof(int*));
    for (int i = 0; i < linhas1; i++) {
        matriz1[i] = (int*)malloc(colunas1 * sizeof(int));
        for (int j = 0; j < colunas1; j++) {
            matriz1[i][j] = i * colunas1 + j;
        }
    }

    int** matriz2 = (int**)malloc(colunas1 * sizeof(int*));
    for (int i = 0; i < colunas1; i++) {
        matriz2[i] = (int*)malloc(colunas2 * sizeof(int));
        for (int j = 0; j < colunas2; j++) {
            matriz2[i][j] = i * colunas2 + j;
        }
    }

    int** resultado = multiplicaMatrizes(matriz1, matriz2, linhas1, colunas1, colunas2);

    if (resultado != NULL) {

        for (int i = 0; i < linhas1; i++) {
            for (int j = 0; j < colunas2; j++) {
                printf("%d ", resultado[i][j]);
            }
            printf("\n");
        }


        for (int i = 0; i < linhas1; i++) {
            free(matriz1[i]);
        }
        free(matriz1);

        for (int i = 0; i < colunas1; i++) {
            free(matriz2[i]);
        }
        free(matriz2);

        for (int i = 0; i < linhas1; i++) {
            free(resultado[i]);
        }
        free(resultado);
    } else {
        printf("A multiplica��o nao e possivel.\n");
    }

    return 0;
}
