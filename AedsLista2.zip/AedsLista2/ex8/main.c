#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main() {
    float salarioBruto;
    float deducaoINSS;
    float deducaoIPRF;

    printf("Digite o valor do salario bruto: ");
    scanf("%f", &salarioBruto);

    if (salarioBruto <= 1320.00) {
        deducaoINSS = salarioBruto * 0.075;
    } else if (salarioBruto <= 2571.29) {
        deducaoINSS = salarioBruto * 0.09;
    } else if (salarioBruto <= 3856.94) {
        deducaoINSS = salarioBruto * 0.12;
    } else if (salarioBruto <= 7507.49) {
        deducaoINSS = salarioBruto * 0.14;
    } else {
        deducaoINSS = 7507.49 * 0.14;
    }

    if (salarioBruto <= 2112.00) {
        deducaoIPRF = 0;
    } else if (salarioBruto <= 2826.65) {
        deducaoIPRF = (salarioBruto - 2112.00) * 0.075;
    } else if (salarioBruto <= 3751.05) {
        deducaoIPRF = (salarioBruto - 2826.65) * 0.15 + 112.43;
    } else if (salarioBruto <= 4664.68) {
        deducaoIPRF = (salarioBruto - 3751.05) * 0.225 + 280.94;
    } else {
        deducaoIPRF = (salarioBruto - 4664.68) * 0.275 + 505.62;
    }

    printf("Deducao do INSS: %.2f\n", deducaoINSS);
    printf("Deducao do IPRF: %.2f\n", deducaoIPRF);

    return 0;
}
