#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main() {
    float lado1, lado2, lado3;
    printf("Digite o tamanho do primeiro lado do triangulo: ");
    scanf("%f", &lado1);
    printf("Digite o tamanho do segundo lado do triangulo: ");
    scanf("%f", &lado2);
    printf("Digite o tamanho do terceiro lado do triangulo: ");
    scanf("%f", &lado3);
    if ((lado1 + lado2 > lado3) && (lado1 + lado3 > lado2) && (lado2 + lado3 > lado1)){
        // tipo de triangulo de acordo com lado
        if(lado1 == lado2 && lado2 ==lado3){
            printf("\nO triangulo e equilatero");
        }
        else if(lado1 == lado2 && lado2 != lado3){
            printf("\nO triangulo e isoceles");
        }
        else if(lado1 == lado3 && lado1 != lado2){
            printf("\nO triangulo e isoceles");
        }
        else if(lado2 == lado3 && lado1 != lado2){
            printf("\nO triangulo e isoceles");
        }else {
            printf("\nO triangulo e escaleno");
        }
        //tipo de triangulo de acordo com angulo
        double alpha = acos((lado2*lado2 + lado3*lado3 - lado1*lado1) / (2 * lado2 * lado3));
        double beta = acos((lado1*lado1 + lado3*lado3 - lado2*lado2) / (2 * lado1 * lado3));
        double gamma = acos((lado1*lado1 + lado2*lado2 - lado3*lado3) / (2 * lado1 * lado2));
        alpha = alpha * 180 / M_PI;
        beta = beta * 180 / M_PI;
        gamma = gamma * 180 / M_PI;
        if (alpha < 90 && beta < 90 && gamma < 90) {
            printf("\nO triangulo e agudo.\n");
        } else if (alpha == 90 || beta == 90 || gamma == 90) {
            printf("nO triangulo e reto\n");
        } else {
            printf("\nO triangulo e obtuso\n");
        }
    }else {
        printf("\n\aCom esses valores nao e possivel formar um triangulo!\n");
    }
    return 0;
}
