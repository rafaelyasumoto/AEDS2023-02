#include <stdio.h>
#include <stdlib.h>

int main()
{
    int numero ;
    printf("Verificador numero par e impar, digite o numero: ");
    scanf("%i", &numero);
    if(numero % 2 == 0){
        printf("\nO numero e par!\n");
    }else
    {
        printf("\nO numero e impar!\n");
    }
    return 0;
}
