#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int idade;
    printf("Digite a idade da pessoa escolhida: ");
    scanf("%i", &idade);
    if(idade<16){
        printf("\nEsta pessoa nao e eleitora\n");
    }
    if(idade == 16 || idade == 17){
        printf("\nEsta pessoa e eleitora facultativa\n");
    }
    if(idade>= 18 && idade<= 64){
        printf("\nEsta pessoa e eleitora obrigatoria\n");
    }
    if(idade>64){
        printf("\nEsta pessoa e eleitora facultativa\n");
    }
    return 0;
}
