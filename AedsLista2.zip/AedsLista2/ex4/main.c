#include <stdio.h>
#include <stdlib.h>

int main() {
    float peso, altura, imc;
    printf("Digite o peso em kg: ");
    scanf("%f", &peso);
    printf("\nDigite a altura em metros: ");
    scanf("%f", &altura );
    imc = peso/(altura*altura);
    if(imc<16){
        printf("IMC menor que 16.\nSituacao: Hecticidade morbida.");
    }
    if(imc>=16 && imc<17){
        printf("IMC entre 16 e 17.\nSituacao: Hecticidade grave.");
    }
    if(imc>=17 && imc<18.5){
        printf("IMC entre 17 e 18.5.\nSituacao: Abaixo do peso.");
    }
    if(imc>=18.5 && imc<25){
        printf("IMC entre 18.5 e 25.\nSituacao: Peso normal.");
    }
    if(imc>=25 && imc<30){
        printf("IMC entre 25 e 30.\nSituacao: Sobrepeso.");
    }
    if(imc>=30 && imc<35){
        printf("IMC entre 30 e 35.\nSituacao: Obesidade.");
    }
    if(imc>=35 && imc<40){
        printf("IMC entre 35 e 40.\nSituacao: Obesidade Grave.");
    }
    if(imc>40){
        printf("IMC maior que 40.\nSituacao: Obesidade Morbida.");
    }

    return 0;
}
