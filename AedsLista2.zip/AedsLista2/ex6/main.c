#include <stdio.h>
#include<stdlib.h>

int main()
{
    int dia;
    printf("Digite o numero do dia da semana(de 1 a 7):");
    scanf("%i", &dia);
    if(dia>=1 && dia<= 7){
        if (dia == 1){
            printf("\nO dia escolhido foi domingo");
        }
        if (dia == 2){
            printf("\nO dia escolhido foi segunda");
        }
        if (dia == 3){
            printf("\nO dia escolhido foi terca");
        }
        if (dia == 4){
            printf("\nO dia escolhido foi quarta");
        }
        if (dia == 5){
            printf("\nO dia escolhido foi quinta");
        }
        if (dia == 6){
            printf("\nO dia escolhido foi sexta");
        }
        if (dia == 7){
            printf("\nO dia escolhido foi sabado");
        }
    }else{
        printf("\nNao existe dia da semana com esse numero!\n");
        return main();
    }
    return 0;
}
