#include <stdio.h>
#include <stdlib.h>


int main() {
    int numero1, numero2, numero3;
    printf("Digite o primeiro numero: ");
    scanf("%i", &numero1);
    printf("Digite o segundo numero: ");
    scanf("%i", &numero2);
    printf("Digite o terceiro numero: ");
    scanf("%i", &numero3);
    if(numero1 > numero2 && numero1 > numero3){
        if(numero2 > numero3){
            printf("%i, %i, %i.", numero1, numero2, numero3);
        }else
        {
            printf("%i, %i, %i.", numero1, numero3, numero2);
        }
    }else if(numero2> numero3)
    {
        if(numero1> numero3)
            {
                printf("%i, %i, %i.", numero2, numero1, numero3);
            }else
                {
                    printf("%i, %i, %i.", numero2, numero3, numero1);
                }
    }else
    {
        if (numero1> numero2)
        {
            printf("%i, %i, %i.", numero3, numero1, numero2);
        }else
        {
            printf("%i, %i, %i.", numero3, numero2, numero1);
        }
    }

    return 0;
}
