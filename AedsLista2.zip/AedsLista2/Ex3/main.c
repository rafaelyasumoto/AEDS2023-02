#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int numero;
    printf("Digite o numero escolhido: ");
    scanf("%i", &numero);
    if(numero % 2 == 0){
        printf("\nO numero e divisivel por 2\n");
    }
    if(numero % 5 == 0){
        printf("\nO numero e divisivel por 5\n");
    }
    if(numero % 10 == 0){
        printf("\nO numero e divisivel por 10\n");
    }
    return 0;
}
