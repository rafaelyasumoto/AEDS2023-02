#include <stdio.h>

struct Horario {
    int hora;
    int minuto;
    int segundo;
};

int validarHorario(int hora, int minuto, int segundo) {
    if (hora >= 0 && hora <= 23 && minuto >= 0 && minuto <= 59 && segundo >= 0 && segundo <= 59) {
        return 1;
    } else {
        return 0;
    }
}

struct Horario somarHorarios(struct Horario horario1, struct Horario horario2) {
    struct Horario resultado;
    int segundosTotais1 = horario1.hora * 3600 + horario1.minuto * 60 + horario1.segundo;
    int segundosTotais2 = horario2.hora * 3600 + horario2.minuto * 60 + horario2.segundo;

    int segundosSoma = segundosTotais1 + segundosTotais2;

    resultado.hora = segundosSoma / 3600;
    resultado.minuto = (segundosSoma % 3600) / 60;
    resultado.segundo = segundosSoma % 60;

    return resultado;
}

int calcularSegundos(struct Horario resultado) {
    if (validarHorario(resultado.hora, resultado.minuto, resultado.segundo)) {
        int segundosTotais = resultado.hora * 3600 + resultado.minuto * 60 + resultado.segundo;
        return segundosTotais;
    } else {
        return -1;
    }
}

int main() {
    struct Horario horario1, horario2, resultado;
    int segundos;

    printf("Digite o primeiro horario (no formato: HH MM SS): ");
    scanf("%d %d %d", &horario1.hora, &horario1.minuto, &horario1.segundo);

    printf("Digite o segundo horario (no formato: HH MM SS): ");
    scanf("%d %d %d", &horario2.hora, &horario2.minuto, &horario2.segundo);

    resultado = somarHorarios(horario1, horario2);
    segundos = calcularSegundos(resultado);

    if (segundos >= 0) {
        printf("Total de segundos: %d\n", segundos);
    } else {
        printf("Hor�rio invalido.\n");
    }

    if (validarHorario(horario1.hora, horario1.minuto, horario1.segundo) &&
        validarHorario(horario2.hora, horario2.minuto, horario2.segundo)) {
        printf("Resultado da soma dos horarios: %02d:%02d:%02d\n", resultado.hora, resultado.minuto, resultado.segundo);
    } else {
        printf("Pelo menos um dos horarios � invalido.\n");
    }

    return 0;
}
