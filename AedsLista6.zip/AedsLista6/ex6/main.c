#include <stdio.h>

struct Horario {
    int hora;
    int minuto;
    int segundo;
};

int validarHorario(int hora, int minuto, int segundo) {
    if (hora >= 0 && hora <= 23 && minuto >= 0 && minuto <= 59 && segundo >= 0 && segundo <= 59) {
        return 1;
    } else {
        return 0;
    }
}

struct Horario criarHorario(int hora, int minuto, int segundo) {
    struct Horario horario;

    if (validarHorario(hora, minuto, segundo)) {
        horario.hora = hora;
        horario.minuto = minuto;
        horario.segundo = segundo;
    } else {
        horario.hora = 0;
        horario.minuto = 0;
        horario.segundo = 0;
    }

    return horario;
}

int main() {
    int hora, minuto, segundo;
    struct Horario horario;

    printf("Digite a hora, minuto e segundo (no formato: HH MM SS): ");
    scanf("%d %d %d", &hora, &minuto, &segundo);

    horario = criarHorario(hora, minuto, segundo);

    if (horario.hora == 0 && horario.minuto == 0 && horario.segundo == 0) {
        printf("Horario invalido.\n");
    } else {
        printf("Horario valido: %02d:%02d:%02d\n", horario.hora, horario.minuto, horario.segundo);
    }

    return 0;
}
