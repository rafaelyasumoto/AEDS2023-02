#include <stdio.h>

struct Data {
    int dia;
    int mes;
    int ano;
};


int main() {

    return 0;
}
