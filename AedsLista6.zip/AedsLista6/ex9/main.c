#include <stdio.h>

struct Data {
    int dia;
    int mes;
    int ano;
};
struct Horario {
    int hora;
    int minuto;
    int segundo;
};

int ehAnoBissexto(int ano) {
    return (ano % 4 == 0 && ano % 100 != 0) || (ano % 400 == 0);
}

int validarData(struct Data data) {
    int diasNoMes[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    if (data.mes < 1 || data.mes > 12) {
        return 0;
    }

    if (data.dia < 1 || data.dia > diasNoMes[data.mes - 1]) {
        if (data.mes == 2 && data.dia == 29 && ehAnoBissexto(data.ano)) {
            return 1;
        }
        return 0;
    }

    return 1;
}

int calcularDiferencaDias(struct Data data1, struct Data data2) {
    if (!validarData(data1) || !validarData(data2)) {
        return -1;
    }


    if (data1.ano > data2.ano ||
        (data1.ano == data2.ano && data1.mes > data2.mes) ||
        (data1.ano == data2.ano && data1.mes == data2.mes && data1.dia > data2.dia)) {
        struct Data temp = data1;
        data1 = data2;
        data2 = temp;
    }

    int diasNoMes[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    int diferencaDias = 0;

    while (data1.ano != data2.ano || data1.mes != data2.mes || data1.dia != data2.dia) {
        if (ehAnoBissexto(data1.ano)) {
            diasNoMes[1] = 29;
        } else {
            diasNoMes[1] = 28;
        }

        int diasNoMesAtual = diasNoMes[data1.mes - 1];
        int diasRestantesNoMes = diasNoMesAtual - data1.dia + 1;

        if (data1.mes == data2.mes && data1.ano == data2.ano) {
            diferencaDias += data2.dia - data1.dia;
            break;
        }

        diferencaDias += diasRestantesNoMes;

        data1.dia = 1;
        data1.mes++;

        if (data1.mes > 12) {
            data1.mes = 1;
            data1.ano++;
        }
    }

    return diferencaDias;
}
int validarHorario(int hora, int minuto, int segundo) {
    if (hora >= 0 && hora <= 23 && minuto >= 0 && minuto <= 59 && segundo >= 0 && segundo <= 59) {
        return 1;
    } else {
        return 0;
    }
}

struct Horario somarHorarios(struct Horario horario1, struct Horario horario2) {
    struct Horario resultado;
    int segundosTotais1 = horario1.hora * 3600 + horario1.minuto * 60 + horario1.segundo;
    int segundosTotais2 = horario2.hora * 3600 + horario2.minuto * 60 + horario2.segundo;

    int segundosSoma = segundosTotais1 + segundosTotais2;

    resultado.hora = segundosSoma / 3600;
    resultado.minuto = (segundosSoma % 3600) / 60;
    resultado.segundo = segundosSoma % 60;

    return resultado;
}

int calcularSegundos(struct Horario resultado) {
    if (validarHorario(resultado.hora, resultado.minuto, resultado.segundo)) {
        int segundosTotais = resultado.hora * 3600 + resultado.minuto * 60 + resultado.segundo;
        return segundosTotais;
    } else {
        return -1;
    }
}

int main() {
    struct Data data1, data2;
    int diferenca;
    struct Horario horario1, horario2, resultado;
    int segundos;

    printf("Digite a primeira data (no formato: DD MM AAAA): ");
    scanf("%d %d %d", &data1.dia, &data1.mes, &data1.ano);

    printf("Digite a segunda data (no formato: DD MM AAAA): ");
    scanf("%d %d %d", &data2.dia, &data2.mes, &data2.ano);
    printf("Digite o primeiro horario (no formato: HH MM SS): ");
    scanf("%d %d %d", &horario1.hora, &horario1.minuto, &horario1.segundo);

    printf("Digite o segundo horario (no formato: HH MM SS): ");
    scanf("%d %d %d", &horario2.hora, &horario2.minuto, &horario2.segundo);

    diferenca = calcularDiferencaDias(data1, data2);

    if (diferenca >= 0) {
        printf("Diferenca de dias entre as duas datas: %d dias\n", diferenca);
    } else {
        printf("Pelo menos uma das datas e invalida.\n");
    }
 resultado = somarHorarios(horario1, horario2);
    segundos = calcularSegundos(resultado);

    if (segundos >= 0) {
        printf("Total de segundos: %d\n", segundos);
    } else {
        printf("Hor�rio invalido.\n");
    }

    if (validarHorario(horario1.hora, horario1.minuto, horario1.segundo) &&
        validarHorario(horario2.hora, horario2.minuto, horario2.segundo)) {
        printf("Resultado da soma dos horarios: %02d:%02d:%02d\n", resultado.hora, resultado.minuto, resultado.segundo);
    } else {
        printf("Pelo menos um dos horarios � invalido.\n");
    }

    return 0;
}
