#include <stdio.h>

struct Horario {
    int hora;
    int minuto;
    int segundo;
};

int main() {

    return 0;
}
