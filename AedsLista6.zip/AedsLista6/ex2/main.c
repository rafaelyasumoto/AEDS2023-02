#include <stdio.h>

struct Data {
    int dia;
    int mes;
    int ano;
};


struct Data validarData(int dia, int mes, int ano) {
    struct Data data;

    if (ano >= 1 && mes >= 1 && mes <= 12) {

        int diasNoMes[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};


        if ((ano % 4 == 0 && ano % 100 != 0) || (ano % 400 == 0)) {
            diasNoMes[1] = 29;
        }

        if (dia >= 1 && dia <= diasNoMes[mes - 1]) {
            data.dia = dia;
            data.mes = mes;
            data.ano = ano;
        } else {
            data.dia = 0;
            data.mes = 0;
            data.ano = 0;
        }
    } else {
        data.dia = 0;
        data.mes = 0;
        data.ano = 0;
    }

    return data;
}

int main() {
    int dia, mes, ano;
    struct Data data;

    printf("Digite o dia, mes e ano (no formato: DD MM AAAA): ");
    scanf("%d %d %d", &dia, &mes, &ano);

    data = validarData(dia, mes, ano);

    if (data.dia == 0 && data.mes == 0 && data.ano == 0) {
        printf("Data invalida.\n");
    } else {
        printf("Data valida: %02d-%02d-%04d\n", data.dia, data.mes, data.ano);
    }

    return 0;
}
