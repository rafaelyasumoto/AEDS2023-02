#include <stdio.h>

struct Data {
    int dia;
    int mes;
    int ano;
};

int ehAnoBissexto(int ano) {
    return (ano % 4 == 0 && ano % 100 != 0) || (ano % 400 == 0);
}

int validarData(struct Data data) {
    int diasNoMes[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    if (data.mes < 1 || data.mes > 12) {
        return 0;
    }

    if (data.dia < 1 || data.dia > diasNoMes[data.mes - 1]) {
        if (data.mes == 2 && data.dia == 29 && ehAnoBissexto(data.ano)) {
            return 1;
        }
        return 0;
    }

    return 1;
}

struct Data adicionarDias(struct Data data, int dias) {
    int diasNoMes[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    while (dias > 0) {
        if (ehAnoBissexto(data.ano)) {
            diasNoMes[1] = 29;
        } else {
            diasNoMes[1] = 28;
        }

        int diasNoMesAtual = diasNoMes[data.mes - 1];
        int diasRestantesNoMes = diasNoMesAtual - data.dia + 1;

        if (dias > diasRestantesNoMes) {

            data.dia = 1;
            data.mes++;

            if (data.mes > 12) {
                data.mes = 1;
                data.ano++;
            }

            dias -= diasRestantesNoMes;
        } else {

            data.dia += dias;
            break;
        }
    }

    return data;
}

int main() {
    struct Data data;
    int dias;

    printf("Digite a data (no formato: DD MM AAAA): ");
    scanf("%d %d %d", &data.dia, &data.mes, &data.ano);

    if (validarData(data)) {
        printf("Digite o numero de dias a serem acrescentados: ");
        scanf("%d", &dias);

        data = adicionarDias(data, dias);

        printf("Nova data: %02d-%02d-%04d\n", data.dia, data.mes, data.ano);
    } else {
        printf("Data inv�lida.\n");
    }

    return 0;
}
