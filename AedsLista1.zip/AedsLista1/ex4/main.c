#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    char nome[100];
    printf("Digite o nome: ");
    fgets(nome, sizeof(nome), stdin);
    if (nome[strlen(nome) - 1] == '\n') {
        nome[strlen(nome) - 1] = '\0';
    }
    int comprimento = strlen(nome);
    printf("O numero de caracteres do nome e: %i\n", comprimento);

    return 0;
}
