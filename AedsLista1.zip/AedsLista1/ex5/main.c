#include <stdio.h>
#include <stdlib.h>


int main() {
    char corHex[7];
    int r, g, b;
    printf("Digite a cor(RRGGBB): ");
    scanf("%6s", corHex);
    sscanf(corHex, "%2x%2x%2x", &r, &g, &b);
    if (r >= 0 && r <= 255 && g >= 0 && g <= 255 && b >= 0 && b <= 255) {
        printf("Valores RGB: R = %d, G = %d, B = %d\n", r, g, b);
    } else {
        printf("Valores inv�lidos.\n");
    }

    return 0;
}





