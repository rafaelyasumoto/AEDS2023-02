#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    float cateto1, cateto2, hipotenusa, area, perimetro, angulo1, angulo2;;
    printf("Digite o valor do primeiro cateto:");
    scanf("%f", &cateto1);
    printf("Digite o valor do segundo cateto:");
    scanf("%f", &cateto2);
    hipotenusa = sqrt(cateto1 * cateto1 + cateto2 * cateto2);
    area = 0.5 * cateto1 * cateto2;
    perimetro = cateto1 + cateto2 + hipotenusa;
    //utilizei ajuda da internet para realizar o c�lculo dos angulos//
    angulo1 = atan(cateto1 / cateto2) * (180.0 / M_PI);
    angulo2 = atan(cateto2 / cateto1) * (180.0 / M_PI);
    printf("\nHipotenusa: %f cm\nArea: %f cm\nPerimetro: %f cm", hipotenusa, area, perimetro);
    printf("\nAngulo adjacente ao primeiro cateto: %f graus\n", angulo1);
    printf("\nAngulo adjacente ao segundo cateto: %f graus\n", angulo2);
    return 0;
}
