#include <stdio.h>
#include<stdlib.h>

int main() {
    int vermelho, verde, azul;
    printf("Cor vermelha: (0 a 255): ");
    scanf("%d", &vermelho);
    printf("Cor verde: (0 a 255): ");
    scanf("%d", &verde);
    printf("Cor azul: (0 a 255): ");
    scanf("%d", &azul);
    if (vermelho >= 0 && vermelho <= 255 &&
        verde >= 0 && verde <= 255 &&
        azul >= 0 && azul <= 255) {
        printf("Valor em hexadecimal: #%02X%02X%02X\n", vermelho, verde, azul);
    } else {
        printf("Valor invalido\n");
    }

    return 0;
}
