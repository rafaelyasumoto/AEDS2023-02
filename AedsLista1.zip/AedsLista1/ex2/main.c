#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    float base =0.0 ;
    float altura = 0.0;
    float resultado = 0.0;
    float resultado2 = 0.0;
    float aux1 = 0.0;
    float lado = 0.0;
    printf("Informe o valor da base :");
    scanf ("%f", &base);
    printf("Informe o valor da altura :");
    scanf ("%f", &altura);
    //calculo area//
    resultado = base + 4 * (sqrt(base/4) * sqrt(base/4) + sqrt(base/4) * altura);
    // calculo volume//
    resultado2 = base/3; resultado2 = resultado2 * altura;
    printf ("\nA area eh eh %fcm2", resultado);
    printf ("\nO volume eh eh %fcm3", resultado2);
    return 0;
}
