#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double calcularProdutoEscalar(double x1, double y1, double x2, double y2) {
    return x1 * x2 + y1 * y2;
}

double calcularMagnitude(double x, double y) {
    return sqrt(x * x + y * y);
}

double calcularAngulo(double x1, double y1, double x2, double y2) {
    double produtoEscalar = calcularProdutoEscalar(x1, y1, x2, y2);
    double magnitude1 = calcularMagnitude(x1, y1);
    double magnitude2 = calcularMagnitude(x2, y2);
    return acos(produtoEscalar / (magnitude1 * magnitude2)) * (180.0 / M_PI);
}

void calcularProdutoVetorial(double x1, double y1, double x2, double y2, double *produtoVetorialX, double *produtoVetorialY) {
    *produtoVetorialX = x1 * y2 - y1 * x2;
    *produtoVetorialY = x1 * y2 - y1 * x2;
}

int main() {
    double x1, y1, x2, y2;
    printf("Digite as coordenadas do primeiro vetor (x y): ");
    scanf("%lf %lf", &x1, &y1);
    printf("Digite as coordenadas do segundo vetor (x y): ");
    scanf("%lf %lf", &x2, &y2);
    double produtoEscalar = calcularProdutoEscalar(x1, y1, x2, y2);
    printf("Produto Escalar: %.2lf\n", produtoEscalar);
    double angulo = calcularAngulo(x1, y1, x2, y2);
    printf("Angulo entre os vetores: %.2lf graus\n", angulo);
    double produtoVetorialX, produtoVetorialY;
    calcularProdutoVetorial(x1, y1, x2, y2, &produtoVetorialX, &produtoVetorialY);
    printf("Produto Vetorial: (%.2lf, %.2lf)\n", produtoVetorialX, produtoVetorialY);

    return 0;
}
