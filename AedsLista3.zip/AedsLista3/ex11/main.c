#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main() {
    float x;
    int n;
    float soma = 0.0;
    printf("digite o valor de x: ");
    scanf("%i", x);
    printf("Digite o numero n de termos: ");
    scanf("%i", n);
    for(int i=1; i<=n; i++){
        float aux= 0.0;
        float aux2 = 0.0;
        aux = pow(-1, i);
        aux2 = pow((-1+x), i);
        soma+= (aux * aux2)/2;
    }
    printf("resultado e %f", soma);
    return 0;
}
