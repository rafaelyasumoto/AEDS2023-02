#include <stdio.h>


int main() {
    int num1, num2;

    // Solicita que o usu�rio insira os dois n�meros
    printf("Digite o primeiro numero : ");
    scanf("%i", &num1);

    printf("Digite o segundo numero: ");
    scanf("%i", &num2);
    int a = num1;
    int b = num2;
    int mdc;

       while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
        mdc = a;

    }
    if (mdc == 1){
        printf("\nOs numeros sao primos entre si");
    }else{
        printf("\nOs numeros nao sao primos entre si");
    }

    return 0;
}
