#include <stdio.h>

int main() {
    int valor;
    int contador_1_25 = 0, contador_26_50 = 0, contador_51_75 = 0, contador_76_100 = 0, total = 0;

    while (1) {
        printf("Digite um numero (entre 1 e 100, ou 0 para sair): ");
        scanf("%d", &valor);

        if (valor == 0) {
            break;
        }

        if (valor < 1 || valor > 100) {
            printf("Numero fora do intervalo permitido. Tente novamente.\n");
            continue;
        }

        total++;

        if (valor >= 1 && valor <= 25) {
            contador_1_25++;
        } else if (valor >= 26 && valor <= 50) {
            contador_26_50++;
        } else if (valor >= 51 && valor <= 75) {
            contador_51_75++;
        } else {
            contador_76_100++;
        }
    }

    if (total > 0) {
        printf("Porcentagem de valores entre 1 e 25: %.2f%%\n", (float)contador_1_25 / total * 100);
        printf("Porcentagem de valores entre 26 e 50: %.2f%%\n", (float)contador_26_50 / total * 100);
        printf("Porcentagem de valores entre 51 e 75: %.2f%%\n", (float)contador_51_75 / total * 100);
        printf("Porcentagem de valores entre 76 e 100: %.2f%%\n", (float)contador_76_100 / total * 100);
    } else {
        printf("Nenhum valor v�lido foi lido.\n");
    }

    return 0;
}
