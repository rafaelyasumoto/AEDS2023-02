#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main() {
    int numero;
    int contador = 0;
    printf("Verificador de primo, digite um numero:");
    scanf("%i", &numero);
    for (int i=2; i<numero; i++){
        if(numero%i == 0){
            contador ++;
        }
    }
    if(contador==0){
        printf("\nO numero e primo");
    }else{
        printf("O numero nao e primo");
    }

    return 0;
}
