#include <stdio.h>
#include <math.h>

int main() {
    double valorImovel, entrada;
    int numMeses;

    double taxaJurosAnual = 0.10;

    printf("Digite o valor do im�vel (R$): ");
    scanf("%lf", &valorImovel);

    printf("Digite o valor da entrada (R$): ");
    scanf("%lf", &entrada);

    printf("Digite o n�mero de meses do empr�stimo: ");
    scanf("%d", &numMeses);
    if (valorImovel <= 100000.0) {
        printf("O valor do im�vel deve ser superior a R$ 100.000,00.\n");
        return 1;
    }
    if (entrada < 0.20 * valorImovel || entrada > 0.75 * valorImovel) {
        printf("O valor da entrada deve estar entre 20%% e 75%% do valor total do im�vel.\n");
        return 1;
    }

    double emprestimo = valorImovel - entrada;

    double amortizacao = emprestimo / numMeses;
    double jurosTotal = 0.0;

    for (int i = 1; i <= numMeses; i++) {
        double juros = (emprestimo * taxaJurosAnual) / 12.0;
        jurosTotal += juros;
        printf("M�s %d - Presta��o: R$ %.2lf - Juros: R$ %.2lf\n", i, amortizacao + juros, juros);
        emprestimo -= amortizacao;
    }

    double valorTotalPago = valorImovel + jurosTotal;

    printf("Valor total pago no final do financiamento: R$ %.2lf\n", valorTotalPago);

    return 0;
}
