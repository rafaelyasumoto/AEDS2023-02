#include <stdio.h>
#include <stdlib.h>

int main()
{
    int soma = 0;
    for(int i=0; i<=1000; i++){
        soma += i ;
    }
    printf("\n%i", soma);
    return 0;
}
