#include <stdio.h>

int main() {
    int numero, soma = 0, contador = 0;

    printf("Digite numeros inteiros (digite 0 para sair):\n");

    while (1) {
        printf("Digite um numero: ");
        scanf("%d", &numero);

        if (numero == 0) {
            break;
        }

        soma += numero;
        contador++;
    }

    if (contador > 0) {
        double media = (double)soma / contador;
        printf("A media dos numeros (excluindo 0) e: %.2lf\n", media);
    } else {
        printf("Nenhum numero valido foi digitado.\n");
    }

    return 0;
}
