#include <stdio.h>
#include <stdlib.h>


int main() {
    int num1, num2;

    printf("Digite o primeiro numero: ");
    scanf("%i", &num1);
    printf("Digite o segundo numero: ");
    scanf("%i", &num2);

     int temp;
     int a = num1;
     int b = num2;

    while (b != 0) {
        temp = b;
        b = a % b;
        a = temp;
    }

    int mmc = (a != 0) ? (num1 * num2) / a : 0;
    printf("O MMC de %i e %i e: %i\n", num1, num2, mmc);
    return 0;
}
