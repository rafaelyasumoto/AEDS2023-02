#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int n ;
    double soma;
    printf("Digite o valor de N: ");
    scanf("%i", &n);
    for(int i = 0; i<= n; i++){
        soma+= 1/pow(2, i);
    }
    printf ("%lf", soma);
    return 0;
}
