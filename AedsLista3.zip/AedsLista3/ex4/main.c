#include <stdio.h>

int main() {
    int n, primeiro = 0, segundo = 1, proximo, i;

    printf("Digite o nemero de termos da sequencia de Fibonacci: ");
    scanf("%d", &n);

    printf("Sequencia de Fibonacci com %i termos:\n", n);

    if (n >= 1) {
        printf("%d ", primeiro);
    }
    if (n >= 2) {
        printf("%d ", segundo);
    }

    for (i = 3; i <= n; i++) {
        proximo = primeiro + segundo;
        printf("%d ", proximo);
        primeiro = segundo;
        segundo = proximo;
    }

    printf("\n");

    return 0;
}
