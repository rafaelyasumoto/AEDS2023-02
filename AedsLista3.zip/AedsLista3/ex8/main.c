#include <stdio.h>

int main() {
    int numero, i;
    float fatorial = 1;

    printf("Digite um numero inteiro positivo: ");
    scanf("%d", &numero);


    if (numero < 0) {
        printf("O fatorial de um n�mero negativo n�o � definido.\n");
    } else {

        for (i = 1; i <= numero; i++) {
            fatorial *= i;
        }

        printf("O fatorial de %d e %f\n", numero, fatorial);
    }

    return 0;
}
