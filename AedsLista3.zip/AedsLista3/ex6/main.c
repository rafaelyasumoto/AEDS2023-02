#include <stdio.h>


int main() {
    int num1, num2;

    // Solicita que o usu�rio insira os dois n�meros
    printf("Digite o primeiro numero : ");
    scanf("%i", &num1);

    printf("Digite o segundo numero: ");
    scanf("%i", &num2);
    int a = num1;
    int b = num2;

       while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    printf("O MDC de %d e %d e %d\n", num1, num2, a);

    return 0;
}
